//
// Created by Orkun Acar on 16.06.2025.
//

#include "mram.h"
#include <stdint.h>
#include <stddef.h>
#include <stdbool.h>

// Function pointer type definitions
typedef bool (*spi_transfer_byte_t)(uint8_t byte);
typedef bool (*gpio_write_t)(int pin, int level);

// Function pointer variables
static spi_transfer_byte_t spi_transfer_byte = NULL;
static gpio_write_t gpio_write = NULL;

// Function to initialize the function pointers
void mram_init(spi_transfer_byte_t spi_func, gpio_write_t gpio_func) {
    spi_transfer_byte = spi_func;
    gpio_write = gpio_func;
}

#define CS_PIN 0 //Your chosen cs number chip select.


//I am trying to write interface for mram mr25h40df
//mram can be operated in spi mode 0 or 3. For both modes inputs are captured on rising edge of the clock and data outputs occur on the falling edge of clock.
/* MRAM Command Set
 * Command    | Description           | Binary Code    | Hex Code | Address | Data Bytes
 * -----------|----------------------|----------------|----------|---------|------------
 * WREN       | Write Enable         | 0000 0110      | 06h      | 0       | 0
 * WRDI       | Write Disable        | 0000 0100      | 04h      | 0       | 0
 * RDSR       | Read Status Register | 0000 0101      | 05h      | 0       | 1
 * WRSR       | Write Status Register| 0000 0001      | 01h      | 0       | 1
 * READ       | Read Data Bytes      | 0000 0011      | 03h      | 3       | 1 to ∞
 * WRITE      | Write Data Bytes     | 0000 0010      | 02h      | 3       | 1 to ∞
 * SLEEP      | Enter Sleep Mode     | 1011 1001      | B9h      | 0       | 0
 * WAKE       | Exit Sleep Mode      | 1010 1011      | ABh      | 0       | 0
 */
#define LOW 0
#define HIGH 1

//MRAM commands
#define MRAM_CMD_WREN 0x06 //Write enable   
#define MRAM_CMD_WRDI 0x04 //Write disable
#define MRAM_CMD_RDSR 0x05 //Read status register
#define MRAM_CMD_WRSR 0x01 //Write status register
#define MRAM_CMD_READ 0x03 //Read data bytes
#define MRAM_CMD_WRITE 0x02 //Write data bytes
#define MRAM_CMD_SLEEP 0xB9 //Enter sleep mode
#define MRAM_CMD_WAKE 0xAB //Exit sleep mode

// MRAM memory size definitions
#define MRAM_SIZE_BYTES (512 * 1024)  // 512KB (4Mbit)
#define MRAM_MAX_ADDRESS (MRAM_SIZE_BYTES - 1)
#define MRAM_ADDRESS_MASK 0x7FFFF  // Mask for bits 0-18 (19 bits total)

bool mram_write_enable(void){
    if(gpio_write(CS_PIN, LOW) != 0) return false;
    if(spi_transfer_byte(MRAM_CMD_WREN) != 0) return false;
    if(gpio_write(CS_PIN, HIGH) != 0) return false;
    return true;
}

//The Write Enable Latch (WEL) is reset to 0 on power-up or when the WRDI command is completed.
bool mram_write_disable(void){
    if(gpio_write(CS_PIN, LOW) != 0) return false;
    if(spi_transfer_byte(MRAM_CMD_WRDI) != 0) return false;
    if(gpio_write(CS_PIN, HIGH) != 0) return false;
    return true;
}

bool mram_read(uint32_t addr, uint8_t* buffer, size_t len){
    if(buffer == NULL || len == 0){
        return false;
    }
    // Apply address mask to ensure only bits 0-18 are used
    addr &= MRAM_ADDRESS_MASK;
    
    // Check if address + length would exceed memory size
    if(addr > MRAM_MAX_ADDRESS || (addr + len - 1) > MRAM_MAX_ADDRESS){
        return false;
    }
    
    if(gpio_write(CS_PIN, LOW) != 0) return false;
    if(spi_transfer_byte(MRAM_CMD_READ) != 0) return false;
    if(spi_transfer_byte((addr >> 16) & 0xFF) != 0) return false;
    if(spi_transfer_byte((addr >> 8) & 0xFF) != 0) return false;
    if(spi_transfer_byte(addr & 0xFF) != 0) return false;
    for(size_t i = 0; i < len; i++){
        buffer[i] = spi_transfer_byte(0xFF);
    }
    if(gpio_write(CS_PIN, HIGH) != 0) return false;
    return true;
}

bool mram_write(uint32_t addr, const uint8_t* data, size_t len){
   if(data == NULL || len == 0){
    return false;
   }
   // Apply address mask to ensure only bits 0-18 are used
   addr &= MRAM_ADDRESS_MASK;
   
   // Check if address + length would exceed memory size
   if(addr > MRAM_MAX_ADDRESS || (addr + len - 1) > MRAM_MAX_ADDRESS){
       return false;
   }
   
   if(mram_write_enable() != 0) return false;

   if(gpio_write(CS_PIN, LOW) != 0) return false;

   if(spi_transfer_byte(MRAM_CMD_WRITE) != 0) return false;

   if(spi_transfer_byte((addr >> 16) & 0xFF) != 0) return false;
   if(spi_transfer_byte((addr >> 8) & 0xFF) != 0) return false;
   if(spi_transfer_byte(addr & 0xFF) != 0) return false;

   for(size_t i = 0; i < len; i++){
    if(spi_transfer_byte(data[i]) != 0) return false;
   }

   if(gpio_write(CS_PIN, HIGH) != 0) return false;
   if(mram_write_disable() != 0) return false;
   return true;
}

bool mram_sleep(void){
    if(gpio_write(CS_PIN, LOW) != 0) return false;
    if(spi_transfer_byte(MRAM_CMD_SLEEP) != 0) return false;
    if(gpio_write(CS_PIN, HIGH) != 0) return false;
    return true;
}

//The CS pin must remain high until the tRDP period is over. WAKE must be executed after sleep mode entry and prior to any other command.
bool mram_wake(void){
    if(gpio_write(CS_PIN, LOW) != 0) return false;
    if(spi_transfer_byte(MRAM_CMD_WAKE) != 0) return false;
    if(gpio_write(CS_PIN, HIGH) != 0) return false; //tRDP period is over.
    return true;
}

/*An RDSR command cannot immediately follow a READ command. If an RDSR command immediately follows a READ com-
mand, the output data will not be correct. Any other sequence of commands is allowed. If an RDSR command is required
immediately following a READ command, it is necessary that another command be inserted before the RDSR is executed.
Alternatively, two successive RDSR commands can be issued following the READ command. The second RDSR will output the
proper state of the Status Register.*/
bool mram_read_status_register(uint8_t* status){
    if(status == NULL) return false;
    if(gpio_write(CS_PIN, LOW) != 0) return false;
    if(spi_transfer_byte(MRAM_CMD_RDSR) != 0) return false;
    *status = spi_transfer_byte(0xFF);
    if(gpio_write(CS_PIN, HIGH) != 0) return false;
    return true;
}

/*The Write Status Register (WRSR) command allows the Status Register to be written. The Status Register can be written to set the write enable latch bit, status register write protect bit, and block write protect bits. The WRSR command is entered by driving CS low, sending the command code, and then driving CS high. The WRSR command cannot immediately follow a READ command. If a WRSR command immediately follows a READ command, the output data will not be correct. Any other sequence of commands is allowed. If a WRSR command is required immediately following a READ command, it is necessary that another command be inserted before the WRSR is executed. Alternatively, two successive WRSR commands can be issued following the READ command. The second WRSR will output the proper state of the Status Register.*/
bool mram_write_status_register(uint8_t status){
    if(mram_write_enable() != 0) return false;
    if(gpio_write(CS_PIN, LOW) != 0) return false;
    if(spi_transfer_byte(MRAM_CMD_WRSR) != 0) return false;
    if(spi_transfer_byte(status) != 0) return false;
    if(gpio_write(CS_PIN, HIGH) != 0) return false;
    if(mram_write_disable() != 0) return false;
    return true;
}

bool mram_is_write_enabled(void){
    uint8_t status;
    if(!mram_read_status_register(&status)) return false;
    return (status & 0x02);
}
