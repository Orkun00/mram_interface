//
// Created by Orkun Acar on 16.06.2025.
//

#ifndef MRAM_H
#define MRAM_H

#include <stdint.h>
#include <stddef.h>

void mram_write(uint32_t addr, const uint8_t* data, size_t len);
void mram_write_enable(void);
void mram_write_disable(void);

#endif //MRAM_H
